<?php
require('common/config.php');

$name=get_safe_value($_POST['name']);
$email=get_safe_value($_POST['email']);
$mobile=get_safe_value($_POST['mobile']);
$password=get_safe_value($_POST['password']);

$res=$con->selectbyCond('users',"email='".$email."'";
$row=$res->fetch_assoc();
$check_user=mysqli_num_rows($res);
if($check_user>0){
	echo "email_present";
}else{
	$added_on=date('Y-m-d h:i:s');
	$rfields=array('name','email','mobile','password','added_on');
	$rvalues=array($name,$email,$mobile,$password,$added_on);
	$res=$con->insert("users",$rfields, $rvalues);
	echo "insert";
}
?>