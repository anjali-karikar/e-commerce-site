<?php
require('common/config.php');
$name=get_safe_value($_POST['name']);
$email=get_safe_value($_POST['email']);
$mobile=get_safe_value($_POST['mobile']);
$comment=get_safe_value($_POST['message']);
$added_on=date('Y-m-d h:i:s');
$rfields=array('name','email','mobile','comment','added_on');
$rvalues=array($name,$email,$mobile,$comment,$added_on);
$res=$con->insert("contact_us",$rfields, $rvalues);
mysqli_query($con,"insert into contact_us(name,email,mobile,comment,added_on) values('$name','$email','$mobile','$comment','$added_on')");
echo "Thank you";
?>