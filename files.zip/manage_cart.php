<?php
$allow=true;
require('common/config.php');

$pid=get_safe_value($_POST['pid']);
$qty=get_safe_value($_POST['qty']);
$type=get_safe_value($_POST['type']);


// using config
if($type=='add'){
	$con->addProduct($pid,$qty);
}

if($type=='remove'){
	$con->removeProduct($pid);
}

if($type=='update'){
	$con->updateProduct($pid,$qty);
}

echo $con->totalProduct();




?>