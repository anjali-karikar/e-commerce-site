<?php
require('common/config.php');

$email=get_safe_value($_POST['email']);
$password=get_safe_value($_POST['password']);

$condition='email= "'.$email.'" and password="'.$password.'"';
$res=$con->selectbyCond('users',$condition);
$row=$res->fetch_assoc();
$check_user=mysqli_num_rows($res);
if($check_user>0){
	// $row=$res->fetch_assoc();
	$_SESSION['USER_LOGIN']='yes';
	$_SESSION['USER_ID']=$row['id'];
	$_SESSION['USER_NAME']=$row['name'];
	echo "valid";
}else{
	echo "wrong";
}
?>