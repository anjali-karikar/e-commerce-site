<?php 
ob_start();
ini_set('session.gc_maxlifetime',3600);
session_start();
error_reporting(0);


if(isset($_SESSION['USER_LOGIN']))
{
	
}
else
{
	if(isset($_POST['username']) ||isset($_POST['password']) || $allow=="true"){
		
	}
	
	else{

        $_SESSION['alert']="warning";
        $_SESSION['msg']="Session Expired! Login Again!!";
          redirect('location:index.php');
        exit;
           redirect('index.php');
		exit;
	}
}

function redirect($url)
	{
		if (!headers_sent())
		{    
			header('Location: '.$url);
			exit;
        }
		else
        {  
			echo '<script type="text/javascript">';
			echo 'window.location.href="'.$url.'";';
			echo '</script>';
			echo '<noscript>';
			echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
			echo '</noscript>'; exit;
		}
	}


function get_safe_value($data) {
          $data = trim($data);
          $data = stripslashes($data);
          $data = htmlspecialchars($data);
          return $data;
        }

function pr($arr){
	echo '<pre>';
	print_r($arr);
}

function prx($arr){
	echo '<pre>';
	print_r($arr);
	die();
}

define('SITE_PATH','http://127.0.0.1/aj/phpeComPart4/phpeComPart4/');
define('PRODUCT_IMAGE_SITE_PATH',SITE_PATH.'media/product/');

$host="localhost";
$username="root";
$password="";
$database="ecom";
spl_autoload_register('myAutoloader');
$con=new DB($host,$username,$password,$database);
function myAutoloader($className)
{
    include $className.'.class.php';
}
?>