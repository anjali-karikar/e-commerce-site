<?php 
// output buffer
ob_start();
// session timeout in seconds
ini_set('session.gc_maxlifetime',3600);
// session start 
session_start();
// To remove all errors, warnings, parse messages, and notices 
error_reporting(0);


// allow only when session is created or allow keyword is set
if(isset($_SESSION['ADMIN_LOGIN']))
{
	// echo $_SESSION['email'];
	// exit;
	
}
else
{
	if(isset($_POST['username']) ||isset($_POST['password']) || $allow=="true"){
		// echo 'allow';exit;
	}
	
	else{

        $_SESSION['alert']="warning";
        $_SESSION['msg']="Session Expired! Login Again!!";
          redirect('location:index.php');
        exit;
           redirect('index.php');
		exit;
	}
}

//redirect function
function redirect($url)
	{
		if (!headers_sent())
		{    
			header('Location: '.$url);
			exit;
        }
		else
        {  
			echo '<script type="text/javascript">';
			echo 'window.location.href="'.$url.'";';
			echo '</script>';
			echo '<noscript>';
			echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
			echo '</noscript>'; exit;
		}
	}



// Making input Secure 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	foreach($_POST as $i=>$j){
		if(is_array($j)){
	
		}else{
	  		$_POST[$i]= get_safe_value($j);
	  	}
	}
}
if ($_SERVER["REQUEST_METHOD"] == "GET") {
	foreach($_GET as $x=>$y){
		if(is_array($y)){
	
		}else{
	  		$_GET[$x]= get_safe_value($y);
	    }
	}
}
	
function get_safe_value($data) {
          $data = trim($data);
          $data = stripslashes($data);
          $data = htmlspecialchars($data);
          return $data;
        }

// functions to print array
function pr($arr){
	echo '<pre>';
	print_r($arr);
}

function prx($arr){
	echo '<pre>';
	print_r($arr);
	die();
}

define('SITE_PATH','http://127.0.0.1/aj/phpeComPart4/phpeComPart4/');
define('PRODUCT_IMAGE_SITE_PATH',SITE_PATH.'media/product/');


// DB Configuration
$host="localhost";
$username="root";
$password="";
$database="ecom";
// creates a queue of autoload functions
spl_autoload_register('myAutoloader');
$con=new DB($host,$username,$password,$database);
function myAutoloader($className)
{
    include $className.'.class.php';
}
?>