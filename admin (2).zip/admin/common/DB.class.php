<?php
class DB { 
    public $connection;
    private $host;
    private $user;
    private $password;
    private $database;
    public $table;
    
    function __construct($host, $user, $password, $database) {
        $this->host       = $host;
        $this->user       = $user;
        $this->password   = $password;
        $this->database   = $database;
        $this->connection=mysqli_connect($this->host,$this->user,$this->password,$this->database);
		//$this->connection = mysqli_connect('localhost', 'username', 'password', 'dbname');
        // Check connection
        if (!$this->connection) {
            die("Connection failed: " . mysqli_connect_error());
        }
        // echo "Connected successfully";exit;
    }
	
    //-----------------------------------------------------------------------------------------------------
    public function close() {
        try {
            mysqli_close($this->connection);
        }
        catch (Exception $Ex) {
            echo $Ex;
        }
    }

    // select all by condition
    public function selectbyCond($table, $condition){
        try{
            $sql = "select * from ".$table." where ".$condition ;
            // echo $sql; exit;    
            $result=mysqli_query($this->connection,$sql);
            return $result;
        }
        catch (Exception $Ex){
            echo $Ex;
        }
    }

    // select all, by col in Ascending order
    public function selectAsc($table,$col) {
        
        //$f= Where $f='$v'
        try {
           $sql = "select * from " . $table ." order by ".$col." asc";
            // echo $sql;exit;
            $result = mysqli_query($this->connection, $sql);
           return $result;
       }
       catch (Exception $Ex) {
           echo $Ex;
       }
    }
     // select all, by col in Descending order
    public function selectDesc($table,$col) {
        
        //$f= Where $f='$v'
        try {
           $sql = "select * from " . $table ." order by ".$col." desc";
            // echo $sql;exit;
            $result = mysqli_query($this->connection, $sql);
           return $result;
       }
       catch (Exception $Ex) {
           echo $Ex;
       }
    }

    public function updatefield($table,$field, $value, $rid) {
        try {
            $sql    = 'UPDATE ' . $table . ' SET ' . $field . '= "' . $value .  '"  WHERE id=' . $rid;
            // echo $sql;exit;
            $result = mysqli_query($this->connection, $sql);
            if ($result) {
                return $result;
            } else {
                return mysqli_error($this->connection);
            }
        }
        catch (Exception $Ex) {
            echo $Ex;
        }
    }

    public function deletRow($table, $condition) {
        try {
            $sql    = 'DELETE FROM '.$table.' WHERE ' . $condition;
            // echo $sql;exit;
            $result = mysqli_query($this->connection, $sql);
            if ($result) {
                return $result;
            } else {
                return mysqli_error($this->connection);
            }
        }
        catch (Exception $Ex) {
            echo $Ex;
        }
    }

    public function insert($table,$rfields, $rvalues) {
        try {
        
            $this->table=$table;
            $fields = implode('`,`', $rfields);
            $values = implode("','", $rvalues);
            $sql    = 'INSERT INTO ' . $this->table . ' (`' . $fields . "`) VALUES ('" . $values . "')";
            
       
            //redirect('location:index.php');
       // echo $sql;exit;
            $result = mysqli_query($this->connection, $sql);
            
            if ($result) {
                return $result;
            } else {
                return mysqli_error($this->connection);
            }
        }
        catch (Exception $Ex) {
            echo $Ex;
        }
    }

    // bulk update fields
     //---------------------------------------------------------------------------------------
    public function update($table,$rfields, $rvalues, $id) {
        try {
            $arraycnt = count($rfields);
            $upstring = '';
            $upstring .= $rfields[0] . '`="' . $rvalues[0] . '"';
            for ($i = 1; $i < $arraycnt; $i++) {
                $upstring .= ', `' . $rfields[$i] . '`="' . $rvalues[$i] . '" ';
            }
              $sql = 'UPDATE `' . $table . '` SET `' . $upstring . 'WHERE id=' . $id;
            
          // echo $sql;exit;
            $result = mysqli_query($this->connection, $sql);
            if ($result) {
                return $result;
            } else {
                return mysqli_error($this->connection);
            }
        }
        catch (Exception $Ex) {
            echo $Ex;
        }
    }

    public function findinfo($table,$f,$ascBy ) {
        try {
            $sql    = 'select ' . $f . '  from ' . $table . ' order by  ' . $ascBy . ' asc';
            // echo $sql;exit;
            $result = mysqli_query($this->connection, $sql);
            return $result;
        }
        catch (Exception $Ex) {
            echo $Ex;
        }
    }

    public function selectbyjoin() {
        
        //$f= Where $f='$v'
        try {
             $sql = "select product.*,categories.categories from product,categories where product.categories_id=categories.id order by product.id desc";
             // echo $sql;exit;
            $result = mysqli_query($this->connection, $sql);
            return $result;
        }
        catch (Exception $Ex) {
            echo $Ex;
        }
    }

    public function selectMultipleTable($selectFields,$tables,$condition) {
        try {
             $sql = "select ". $selectFields." from ". $tables ." where ". $condition;

            // echo $sql;exit;
            $result = mysqli_query($this->connection, $sql);
            return $result;
        }
        catch (Exception $Ex) {
            echo $Ex;
        }
    }




}    