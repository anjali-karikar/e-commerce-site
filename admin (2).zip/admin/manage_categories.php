<?php
require('top.inc.php');
$categories='';
$msg='';

if(isset($_GET['id']) && $_GET['id']!=''){
	$id=get_safe_value($_GET['id']);
	$condition='id='.$id;
    $res=$con->selectbyCond('categories',$condition);
	$getData=$res->fetch_assoc();
	$check= $getData['id'];  
	if(isset($check)){
		$categories=$getData['categories'];
	}else{
		redirect('categories.php');
	}
}

if(isset($_POST['submit'])){
	$categories=get_safe_value($_POST['categories']);
	$condition='categories="'.$categories.'"';
    $res=$con->selectbyCond('categories',$condition);
    $getData=$res->fetch_assoc();
	$check= $getData['id'];  
	if(isset($check)){
		// for editing existing category
		if(isset($_GET['id']) && $_GET['id']!=''){
			if($id==$getData['id']){
			
			}else{
				$msg="Categories already exist";
			}
		}//for adding new category
		else{
			$msg="Categories already exist";
		}
	}
	
	if($msg==''){
		if(isset($_GET['id']) && $_GET['id']!=''){
			$updateField=$con->updatefield("categories","categories", $categories, $id);
		}else{
			$rfields=array("categories","status");
			$rvalues=array($categories,1);
			$Insert=$con->insert("categories",$rfields, $rvalues);
		}
		redirect('categories.php');
	}
}
?>
<div class="content pb-0">
            <div class="animated fadeIn">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="card">
                        <div class="card-header"><strong>Categories</strong><small> Form</small></div>
                        <form method="post">
							<div class="card-body card-block">
							   <div class="form-group">
									<label for="categories" class=" form-control-label">Categories</label>
									<input type="text" name="categories" placeholder="Enter categories name" class="form-control" required value="<?php echo $categories?>">
								</div>
							   <button id="payment-button" name="submit" type="submit" class="btn btn-sm btn-primary ">
							   <span id="payment-button-amount">Submit</span>
							   </button>
							   <a class="btn btn-sm btn-warning " href="categories.php">
							   <span id="payment-button-amount">Back </span>
							   </a>
							   <div class="field_error"><?php echo $msg?></div>
							</div>
						</form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         
<?php
require('footer.inc.php');
?>