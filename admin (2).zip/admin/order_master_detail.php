<?php
require('top.inc.php');
$order_id=get_safe_value($_GET['id']);
if(isset($_POST['update_order_status'])){
	$update_order_status=$_POST['update_order_status'];
	if($update_order_status=='5'){
		$rfields=array("order_status", "payment_status");
		$rvalues=array($update_order_status, 'Success');
		$con->update("`order`",$rfields, $rvalues, $order_id);
		
	}else{
		$con->updatefield("`order`","order_status", $update_order_status, $order_id);
		// mysqli_query($con,"update `order` set order_status='$update_order_status' where id='$order_id'");
	}
	
}
?>
<div class="content pb-0">
	<div class="orders">
	   <div class="row">
		  <div class="col-xl-12">
			 <div class="card">
				<div class="card-body">
				   <h4 class="box-title">Order Detail </h4>
				</div>
				<div class="card-body--">
				   <div class="table-stats order-table ov-h">
					  <table class="table">
								<thead>
									<tr>
										<th class="product-thumbnail">Product Name</th>
										<th class="product-thumbnail">Product Image</th>
										<th class="product-name">Qty</th>
										<th class="product-price">Price</th>
										<th class="product-price">Total Price</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$selectFields="distinct(order_detail.id) ,order_detail.*,product.name,product.image,`order`.address,`order`.city,`order`.pincode";
                                    $tables="order_detail,product ,`order`";
                                    $condition="order_detail.id=".$order_id." and  order_detail.product_id=product.id GROUP by order_detail.id";
                                    $res=$con->selectMultipleTable($selectFields,$tables,$condition);

									
									$total_price=0;
									$cond= "id=".$order_id;
									$ress=$con->selectbyCond("`order`", $cond);
									$userInfo=$ress->fetch_assoc();
									// $userInfo=mysqli_fetch_assoc(mysqli_query($con,"select * from `order` where id='$order_id'"));
									
									$address=$userInfo['address'];
									$city=$userInfo['city'];
									$pincode=$userInfo['pincode'];
									
									while($row=mysqli_fetch_assoc($res)){
									
									$total_price=$total_price+($row['qty']*$row['price']);
									?>
									<tr>
										<td class="product-name"><?php echo $row['name']?></td>
										<td class="product-name"> <img src="<?php echo PRODUCT_IMAGE_SITE_PATH.$row['image']?>"></td>
										<td class="product-name"><?php echo $row['qty']?></td>
										<td class="product-name"><?php echo $row['price']?></td>
										<td class="product-name"><?php echo $row['qty']*$row['price']?></td>
										
									</tr>
									<?php } ?>
									<tr>
										<td colspan="3"></td>
										<td class="product-name">Total Price</td>
										<td class="product-name"><?php echo $total_price?></td>
										
									</tr>
								</tbody>
							
						</table>
						<div id="address_details">
							<strong>Address</strong>
							<?php echo $address?>, <?php echo $city?>, <?php echo $pincode?><br/><br/>
							<strong>Order Status</strong>
							<?php 
							$selectFields="order_status.name";
                            $tables="order_status,`order`";
                            $condition="`order`.id='".$order_id."' and `order`.order_status=order_status.id";
                            $result_order_status_arr=$con->selectMultipleTable($selectFields,$tables,$condition);
							$order_status_arr=$result_order_status_arr->fetch_assoc();
							echo $order_status_arr['name'];
							?>
							<br><br>
							<div>
								<form method="post">
									<select class="form-control" name="update_order_status" required>
										<option value="">Select Status</option>
										<?php
										$res=$con->selectAsc("order_status","id");
										while($row=$res->fetch_assoc()){
											if($row['id']==$categories_id){
												echo "<option selected value=".$row['id'].">".$row['name']."</option>";
											}else{
												echo "<option value=".$row['id'].">".$row['name']."</option>";
											}
										}
										?>
									</select>
									<br>
									<input type="submit" class="form-control"/>
								</form>
							</div>
						</div>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
</div>
<?php
require('footer.inc.php');
?>