<?php
require('top.inc.php');

if(isset($_GET['type']) && $_GET['type']!=''){
	$type=get_safe_value($_GET['type']);
	if($type=='delete'){
		$id=get_safe_value($_GET['id']);
		$condition="id=".$id;
		$deleteRow=$con->deletRow("contact_us", $condition);
	}
}

$DescCondition='id';
$resultContact=$con->selectDesc('contact_us',$DescCondition);
?>
<div class="content pb-0">
	<div class="orders">
	   <div class="row">
		  <div class="col-xl-12">
			 <div class="card">
				<div class="card-body">
				   <h4 class="box-title">Contact Us </h4>
				</div>
				<div class="card-body--">
				   <div class="table-stats order-table ov-h">
					  <table class="table ">
						 <thead>
							<tr>
							   <th class="serial">#</th>
							   <th>ID</th>
							   <th>Name</th>
							   <th>Email</th>
							   <th>Mobile</th>
							   <th>Query</th>
							   <th>Date</th>
							   <th></th>
							</tr>
						 </thead>
						 <tbody>
							<?php 
							$i=1;
							while($rowContactUs=$resultContact->fetch_assoc()){?>
							<tr>
							   <td class="serial"><?php echo $i?></td>
							   <td><?php echo $rowContactUs['id']?></td>
							   <td><?php echo $rowContactUs['name']?></td>
							   <td><?php echo $rowContactUs['email']?></td>
							   <td><?php echo $rowContactUs['mobile']?></td>
							   <td><?php echo $rowContactUs['comment']?></td>
							   <td><?php echo $rowContactUs['added_on']?></td>
							   <td>
								<?php
								echo "<span class='badge badge-delete'><a href='?type=delete&id=".$rowContactUs['id']."'>Delete</a></span>";
								?>
							   </td>
							</tr>
							<?php } ?>
						 </tbody>
					  </table>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
</div>
<?php
require('footer.inc.php');
?>